package booduu

class ProfileController {
    static scaffold = true
}
