package booduu

class TagController {
    static scaffold = true
}
